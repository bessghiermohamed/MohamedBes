import { useState } from 'react';
import { Star, Users, Building, Lightbulb, ChevronRight, ChevronLeft, Check, Sparkles, Brain, Smile } from 'lucide-react';

type Category = 'teaching' | 'environment' | 'infrastructure' | 'fun';
type QuestionType = 'rating' | 'multiple' | 'fun';

interface Question {
  id: string;
  category: Category;
  type: QuestionType;
  question: string;
  options?: string[];
  icon?: React.ReactNode;
}

const questions: Question[] = [
  // Teaching Category
  {
    id: 't1',
    category: 'teaching',
    type: 'rating',
    question: 'كيف تقيّم جودة أساليب التدريس لدى الأساتذة؟',
    icon: <Star className="w-5 h-5" />,
  },
  {
    id: 't2',
    category: 'teaching',
    type: 'rating',
    question: 'هل تجد أن الأساتذة يستخدمون أساليب تدريس متنوعة ومبتكرة؟',
    icon: <Star className="w-5 h-5" />,
  },
  {
    id: 't3',
    category: 'teaching',
    type: 'multiple',
    question: 'ما أكثر جانب إيجابي في تدريس الأساتذة؟',
    options: ['الوضوح في الشرح', 'التشجيع على التفكير', 'استخدام التكنولوجيا', 'التعامل مع الطلاب'],
  },
  // Environment Category
  {
    id: 'e1',
    category: 'environment',
    type: 'rating',
    question: 'كيف تقيّم العلاقات بين الطلاب في المؤسسة؟',
    icon: <Users className="w-5 h-5" />,
  },
  {
    id: 'e2',
    category: 'environment',
    type: 'rating',
    question: 'هل تشعر بالراحة في الأجواء الدراسية؟',
    icon: <Users className="w-5 h-5" />,
  },
  {
    id: 'e3',
    category: 'environment',
    type: 'multiple',
    question: 'ما أهم تحسن يمكن إجراؤه في البيئة الدراسية؟',
    options: ['مساحات ترفيهية', 'دعم نفسي أكاديمي', 'أنشطة اجتماعية', 'تحسين المناخ العام'],
  },
  // Infrastructure Category
  {
    id: 'i1',
    category: 'infrastructure',
    type: 'rating',
    question: 'كيف تقيّم جودة المرافق والبنية التحتية؟',
    icon: <Building className="w-5 h-5" />,
  },
  {
    id: 'i2',
    category: 'infrastructure',
    type: 'rating',
    question: 'هل المكتبات والمختبرات مجهزة بشكل كافٍ؟',
    icon: <Building className="w-5 h-5" />,
  },
  {
    id: 'i3',
    category: 'infrastructure',
    type: 'multiple',
    question: 'ما أكثر ما يحتاج لتحسين في المؤسسة؟',
    options: ['المعدات التقنية', 'المكتبة', 'المختبرات', 'القاعات'],
  },
  // Fun Questions
  {
    id: 'f1',
    category: 'fun',
    type: 'multiple',
    question: '🧠 لو كان لديك مليون دولار ولكن يجب التخلي عن شيء واحد، ماذا ستختار؟',
    options: ['الدراسة', 'الصحة', 'العائلة', 'الصديق المقرب', 'الهوايات'],
    icon: <Brain className="w-5 h-5" />,
  },
  {
    id: 'f2',
    category: 'fun',
    type: 'multiple',
    question: '🌍 إذا كان يجب أن تختار رأيًا واحدًا حول الصراع الأخير بين Iran وإسرائيل، ماذا ستختار؟',
    options: ['أؤيد Israel', 'أؤيد Iran', 'محايد بالكامل', 'لا يهمني الموضوع', 'أحتاج لمزيد من المعلومات'],
    icon: <Lightbulb className="w-5 h-5" />,
  },
  {
    id: 'f3',
    category: 'fun',
    type: 'fun',
    question: '😂 لو اضطررت للتخلص من أحد زملائك في العمل، من ستختار؟ (نكتة فقط!)',
    icon: <Smile className="w-5 h-5" />,
  },
  {
    id: 'f4',
    category: 'fun',
    type: 'multiple',
    question: '🎭 لو كنت ممثلاً في فيلم، ما الدور الذي تريده أكثر؟',
    options: ['بطل أكشن', 'كوميدي', 'رومانسي', 'شرير', 'عالم صامت'],
    icon: <Sparkles className="w-5 h-5" />,
  },
  {
    id: 'f5',
    category: 'fun',
    type: 'fun',
    question: '💡 إذا كان بمقدورك تغيير شيء واحد في المؤسسة، ماذا سيكون؟',
    icon: <Lightbulb className="w-5 h-5" />,
  },
];

const categories = [
  { id: 'teaching' as Category, name: 'الأساتذة وطرق التدريس', color: 'bg-blue-500', icon: <Star className="w-6 h-6" /> },
  { id: 'environment' as Category, name: 'الجو الدراسي والعلاقات', color: 'bg-green-500', icon: <Users className="w-6 h-6" /> },
  { id: 'infrastructure' as Category, name: 'البنية التحتية والإمكانيات', color: 'bg-purple-500', icon: <Building className="w-6 h-6" /> },
  { id: 'fun' as Category, name: 'أسئلة ممتعة ومتنوعة', color: 'bg-pink-500', icon: <Lightbulb className="w-6 h-6" /> },
];

export default function App() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | number>>({});
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [showResults, setShowResults] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];

  const filteredQuestions = selectedCategory
    ? questions.filter(q => q.category === selectedCategory)
    : questions;

  const handleAnswer = (questionId: string, answer: string | number) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < filteredQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleCategorySelect = (category: Category) => {
    setSelectedCategory(category);
    setCurrentQuestionIndex(0);
    setShowResults(false);
  };

  const handleReset = () => {
    setSelectedCategory(null);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setShowResults(false);
  };

  const getCategoryStats = (category: Category) => {
    const categoryQuestions = questions.filter(q => q.category === category);
    const answered = categoryQuestions.filter(q => answers[q.id] !== undefined).length;
    return { answered, total: categoryQuestions.length };
  };

  const renderStars = (questionId: string) => {
    const currentRating = (answers[questionId] as number) || 0;
    return (
      <div className="flex gap-2 justify-center">
        {[1, 2, 3, 4, 5].map(star => (
          <button
            key={star}
            onClick={() => handleAnswer(questionId, star)}
            className={`p-2 rounded-full transition-all duration-300 ${
              star <= currentRating
                ? 'bg-yellow-400 text-white scale-110'
                : 'bg-gray-200 text-gray-400 hover:bg-yellow-100'
            }`}
          >
            <Star className={`w-8 h-8 ${star <= currentRating ? 'fill-current' : ''}`} />
          </button>
        ))}
      </div>
    );
  };

  if (showResults) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
              📊 ملخص تقييمك
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {categories.map(cat => {
                const stats = getCategoryStats(cat.id);
                return (
                  <div
                    key={cat.id}
                    className={`${cat.color} rounded-2xl p-6 text-white`}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      {cat.icon}
                      <h3 className="font-bold text-lg">{cat.name}</h3>
                    </div>
                    <div className="text-4xl font-bold mb-2">
                      {Math.round((stats.answered / stats.total) * 100)}%
                    </div>
                    <p className="opacity-80">
                      {stats.answered} من {stats.total} سؤال
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="bg-gray-50 rounded-2xl p-6 mb-6">
              <h3 className="font-bold text-xl mb-4 text-gray-700">📝 إجاباتك</h3>
              <div className="space-y-4">
                {filteredQuestions.map(q => (
                  <div key={q.id} className="border-b pb-4">
                    <p className="font-medium text-gray-800 mb-2">{q.question}</p>
                    <p className="text-gray-600">
                      {q.type === 'rating'
                        ? `⭐ ${answers[q.id] || 'لم يُجب'} من 5`
                        : answers[q.id] || 'لم يُجب'
                      }
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleReset}
              className="w-full py-4 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-xl font-bold text-lg hover:opacity-90 transition-all"
            >
              إعادة التقييم
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!selectedCategory) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              📋 تقييم الزملاء
            </h1>
            <p className="text-xl text-white/80">
            教学质量 / تكوين المعلمين
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => handleCategorySelect(cat.id)}
                className={`${cat.color} rounded-2xl p-8 text-white transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl`}
              >
                <div className="flex items-center gap-4 mb-4">
                  {cat.icon}
                  <h2 className="text-2xl font-bold">{cat.name}</h2>
                </div>
                <p className="opacity-80 mb-4">
                  {getCategoryStats(cat.id).answered} / {getCategoryStats(cat.id).total} مجاب
                </p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className={`h-2 flex-1 rounded-full ${
                        i < getCategoryStats(cat.id).answered ? 'bg-white' : 'bg-white/30'
                      }`}
                    />
                  ))}
                </div>
              </button>
            ))}
          </div>

          <button
            onClick={() => handleCategorySelect('teaching')}
            className="w-full mt-8 py-4 bg-white text-indigo-900 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all"
          >
            ابدأ التقييم الشامل
          </button>
        </div>
      </div>
    );
  }

  const selectedCat = categories.find(c => c.id === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className={`${selectedCat?.color} rounded-3xl p-6 text-white mb-8 shadow-xl`}>
          <button
            onClick={handleReset}
            className="mb-4 opacity-80 hover:opacity-100 transition-all"
          >
            ← رجوع للصفحة الرئيسية
          </button>
          <div className="flex items-center gap-4">
            {selectedCat?.icon}
            <h1 className="text-2xl md:text-3xl font-bold">{selectedCat?.name}</h1>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-white/20 rounded-full h-3 mb-8 overflow-hidden">
          <div
            className="bg-gradient-to-r from-yellow-400 to-orange-500 h-full rounded-full transition-all duration-500"
            style={{ width: `${((currentQuestionIndex + 1) / filteredQuestions.length) * 100}%` }}
          />
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12">
          <div className="text-center mb-8">
            <span className="text-sm text-gray-500">
              السؤال {currentQuestionIndex + 1} من {filteredQuestions.length}
            </span>
            <h2 className="text-xl md:text-2xl font-bold text-gray-800 mt-2">
              {currentQuestion.question}
            </h2>
          </div>

          {/* Answer Section */}
          <div className="mb-8">
            {currentQuestion.type === 'rating' && (
              renderStars(currentQuestion.id)
            )}

            {currentQuestion.type === 'multiple' && currentQuestion.options && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentQuestion.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(currentQuestion.id, option)}
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      answers[currentQuestion.id] === option
                        ? 'border-indigo-500 bg-indigo-50 text-indigo-700'
                        : 'border-gray-200 hover:border-indigo-300 hover:bg-gray-50'
                    }`}
                  >
                    <span className="font-medium">{option}</span>
                  </button>
                ))}
              </div>
            )}

            {currentQuestion.type === 'fun' && (
              <textarea
                onChange={(e) => handleAnswer(currentQuestion.id, e.target.value)}
                value={(answers[currentQuestion.id] as string) || ''}
                placeholder="اكتب إجابتك هنا... 🤔"
                className="w-full h-32 p-4 border-2 border-gray-200 rounded-xl focus:border-indigo-500 focus:outline-none resize-none text-right"
                dir="rtl"
              />
            )}
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between gap-4">
            <button
              onClick={handlePrevious}
              disabled={currentQuestionIndex === 0}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                currentQuestionIndex === 0
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <ChevronRight className="w-5 h-5" />
              السابق
            </button>

            <button
              onClick={handleNext}
              disabled={answers[currentQuestion.id] === undefined}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                answers[currentQuestion.id] === undefined
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white hover:opacity-90'
              }`}
            >
              {currentQuestionIndex === filteredQuestions.length - 1 ? 'عرض النتائج' : 'التالي'}
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Category Quick Switch */}
        <div className="mt-6 flex justify-center gap-2 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => handleCategorySelect(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCategory === cat.id
                  ? `${cat.color} text-white`
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}